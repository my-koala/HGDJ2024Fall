6/13/24

Heya, Borneo here!

Thanks for downloading my font!
This font means a lot to me since this is my first font made, and it is likely my last font made at my old high school.

You see, I took a class on video game design and development with a super cool teacher, Mr. L.
Mr. L is one of the kindest and most encouraging teachers, and he also hosted an in-school HAM Radio group.
In this group I got to go on air, attend meetings and achieve things I didn't know were possible.
Thanks to him, I'm more knowledgeable about HAM Radio and Video Game Development.

In his class we got to use Adobe Illustrator, and I got to use some vectors since I had only used Photopea. (AKA; Knockoff Photoshop)
He told us that vectors were one of the most useful digital tools, since they could be upscaled, easy to edit and even printed out on our clothes. At first I was reluctant to use this tool. I mean, why would I use the more complicated illustrator if I've got the more familiar photoshop next door? But then, he taught us how to use it more and more, so then I got the hang of it! I could finally make some decent vectors, get a grade and be done. But I can't just stop there, most people who know me would describe me as an overachiever and so I did as I usually did. 

With less than an hour left in our final class, when I finished up my game I made this font. I had to rush through it, so that's why it's only lowercase letters and some sloppy punctuation marks. And voila, this font was made! Is this font anything revolutionizing? Is it eye-catching? Could you turn in a paper with this font? 

No. None of that is true. You'd need to be a dummy to turn in something with this font, hence the name Dummy Daze.
As a matter of fact, if any of you dummies do hand in a paper in this font please send it online. I'd like to get a good laugh out of it.

Speaking of the name Dummy Daze, it took me a while to come up with the name. It's placeholder name was "Tingum", since it's Caribbean slang for someone or something. I chose it mainly because of it's sound, it was stuck in my head and it has a nice ring to it. But then I someone mentioned that they first heard the word "tingum" in an inappropriate YouTube skit. If you know, you know. I settled on Dummy Daze since my friend Huber had suggested that as a name, so it stuck.

Back to what I was saying, when this font was made, I had struggled with the lowercase "e", and so I actually got Mr. L to do it! And whatever you are typing with this font, I hope you contribute something meaningful. This font is dedicated to all the innovators of the world, the most bravest and creative minds and most importantly dedicated to Mr. L, Thank you.

So whenever you type in this font, type with pride, knowing you own your font. You literally own this font, I waiver my rights to this font into the public domain.

//  Dummy Daze by Borneo is marked with CC0 1.0 //

P.S. : I know some dummy is going to take credit for this and scrap me out of the picture. If I need to prove myself I'll fill in the blanks. W--UD , M---e-- C----s.